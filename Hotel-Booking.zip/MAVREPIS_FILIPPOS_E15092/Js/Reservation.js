var check = {};

//Check if a radio is selected for stay (One night-Multiple)
function checkradioselect() {
    var radios = document.getElementsByName('stay');
    var flag = false;
    var value;
    for (var i = 0; i < radios.length; i++) {
        if (radios[i].type === 'radio' && radios[i].checked) {
            value = radios[i].value;
            check.radio = true;
        }
    }
    return flag;
}

//Check if a radio is selected for hotel
function checkradiosimgelect() {
    var radios = document.getElementsByName('radioimg');
    var flag = false;
    var value;
    for (var i = 0; i < radios.length; i++) {
        if (radios[i].type === 'radio' && radios[i].checked) {
            value = radios[i].value;
            check.radioimg = true;

            check.i = i;
        }
    }
    return flag;
}
//Enables Submit if dates and radios are correct
function checkform() {
    var flag = false;
    if ((check.radio) && (check.dates) && (check.radioimg)) {
        flag = true;
    }
    document.getElementById('submitbutton').disabled = !flag;
}
//Enables show total cost Btn if checkboxes and breakfast are correct
function enablecosts() {
    if (numcheckboxselect() && checkedbreakfast())
        document.getElementById("btn-show-cost").disabled = !numcheckboxselect();
}
//Enables btn to next step 
function enablenext() {
    document.getElementById("btn-to-next").disabled = false;
}
//Sets autodate when One night is selected using 1st Date input
function autodate() {
    var radios = document.getElementsByTagName('input');
    var flag = false;
    if (radios[4].type === 'radio' && radios[4].checked) {
        value = radios[4].value;
        flag = true;
    }
    if (flag) {
        document.getElementById("seconddate").attributes["type"].value = "text";
        var tt = document.getElementById("firstdate").value;
        var date = new Date(tt);
        var newdate = new Date(tt);
        newdate.setDate(newdate.getDate() + 1);
        var dd = newdate.getDate();
        var mm = newdate.getMonth() + 1;
        var y = newdate.getFullYear();
        var someFormattedDate = mm + '/' + dd + '/' + y;
        document.getElementById("seconddate").value = someFormattedDate;
    }
}

function enableonenight() {
    document.getElementById("onenight").disabled = false;
}
//Calculates Days difference between Date of Arrival and Date of Departure
function calculateDays() {

    var radios = document.getElementsByTagName('input');
    var diffDays = 0;
    var fd = document.getElementById("firstdate").value;
    var sd = document.getElementById("seconddate").value;
    if (radios[4].type === 'radio' && radios[4].checked) {
        value = radios[4].value;
        timeDiff = 86400000;
    } else {
        var date1 = new Date(fd);
        var date2 = new Date(sd);
        var timeDiff = Math.abs(date2.getTime() - date1.getTime());
    }
    var diffDays = Math.ceil(timeDiff / (1000 * 3600 * 24));
    return diffDays;
}
//Manipulates second input to change it's type to date when needed
function settodate() {
    document.getElementById("seconddate").attributes["type"].value = "date";
}
//Checks validity of date fields
function validate() {
    var tt1 = document.getElementById("firstdate").value;
    var date1 = new Date(tt1);
    var flag = false;
    var tt2 = document.getElementById("seconddate").value;
    var date2 = new Date(tt2);
    var compdate = new Date("June 15,2017 03:00:00");
    var lowlim = new Date("June 11,2017 03:00:00");
    var flag = false;

    if ((date1 < date2) && (date1 < compdate) && (date1 >= lowlim) && (date2 <= compdate) && (date2 >= lowlim)) {
        check.dates = true;
    } else {
        alert("wrong dates");
    }
    return flag;
}
//Back Button
function enableformone() {
    var fields = document.getElementById("stepone").getElementsByTagName('*');
    var not = document.getElementById("submitbutton");
    var not1 = document.getElementById("onenight");
    var form = document.getElementById("formone");
    for (var i = 0; i < fields.length; i++) {
        if (fields[i] === not || fields[i] === not1) continue;
        fields[i].disabled = false;
    }
    resetForm(form);
    document.getElementById("steptwo").style.display = "none";
    document.getElementsByTagName("header")[0].innerHTML = "<h1> 1o Bήμα </h1>";
}

function enableformtwo() {
    var fields = document.getElementById("steptwo").getElementsByTagName('*');
    var form = document.getElementById("secondform");
    var not1 = document.getElementById("btn-to-next");
    var not2 = document.getElementById("btn-show-cost");
    for (var i = 0; i < fields.length; i++) {
        if (fields[i] === not1 || fields[i] === not2) continue;
        fields[i].disabled = false;
    }
    resetForm(form);
    document.getElementById("stepthree").style.display = "none";
    document.getElementsByTagName("header")[0].innerHTML = "<h1> 2o Bήμα </h1>";
}

function firstmod() {
    document.getElementById("modtxt").innerHTML = "<h2>Fairmont Hotel</h2> </br> Discover a luxurious Hawaii resort on the Kohala Coast inspired by Culture, Well-Being and Genuine Aloha.  From Mauna Kea's winter snow-capped mountaintop to the flowing lava of Kilauea Volcano to tropical rainforests and a teeming undersea world, the Big Island of Hawaii has much to offer the spirited traveler. </br>  </br>Τιμη μονοκλινου:200 Ευρώ </br> Τιμη Δικλινου:350 Ευρώ ";
    document.getElementById("modimg").setAttribute("src", "../images/Fairmont.jpeg");
}

function secondmod() {
    document.getElementById("modtxt").innerHTML = "<h2>Lai Nani Hotel</h2> </br> Located in North Hilo in the The Big Island Region, 23 km from Hilo, Lai Nani Oceanfront Estate offers guest bungalows with private decks. Free WiFi is offered on the entire property. It is located across the street from Uma Uma Falls.</br>  </br>Τιμη μονοκλινου:150 Ευρώ </br> Τιμη Δικλινου:250 Ευρώ ";
    document.getElementById("modimg").setAttribute("src", "../images/Lai Nani.jpg");
}

function thirdmod() {
    document.getElementById("modtxt").innerHTML = "<h2>Ritz-Carlton Resort </h2> <br>A hike through the lush rainforest, a round of championship golf, the warmth of golden sand beneath your feet, the excitement of a young mind as it learns about the wonders of nature. These are among the experiences that await guests at The Ritz-Carlton, Kapalua.</br>  </br>Τιμη μονοκλινου:300 Ευρώ </br> Τιμη Δικλινου:450 Ευρώ";
    document.getElementById("modimg").setAttribute("src", "../images/Ritz-Carlton.jpg");
}

function fourthmod() {
    document.getElementById("modtxt").innerHTML = "<h2> Montage Kapalua Hotel</h2> <br>Set beachfront atop picturesque Kapalua Bay, this 24 acre Maui resort is the ideal destination from which to experience Hawaiian lifestyle at its finest. At Montage Kapalua Bay, you will feel embraced by genuine island hospitality and authentic culture. At every turn, the spirit of Hawaii merges with your own to create pono — a true sense of balance and harmony<br> <br>Τιμη μονοκλινου:250 Ευρώ </br> Τιμη Δικλινου:300 Ευρώ";
    document.getElementById("modimg").setAttribute("src", "../images/Montage.jpg");
}
//Proceed Button (Step One -> Step Two)
function disableformone() {
    var fields = document.getElementById("stepone").getElementsByTagName('*');
    for (var i = 0; i < fields.length; i++) {
        fields[i].disabled = true;
    }
    var formtwo = document.getElementById("secondform");
    resetForm(formtwo);
    document.getElementById("steptwo").style.display = "block";
    document.getElementsByTagName("header")[0].innerHTML = "<h1> 2o Bήμα </h1>";
}
//Next Button (Step Two -> Step Three)
function disableformtwo() {
    var fields = document.getElementById("steptwo").getElementsByTagName('*');
    for (var i = 0; i < fields.length; i++) {
        fields[i].disabled = true;
    }
    var form = document.getElementById("formthree");
    resetForm(form);
    document.getElementById("stepthree").style.display = "block";
    document.getElementsByTagName("header")[0].innerHTML = "<h1> 3o Bήμα </h1>";
}
//Checks if at least two comforts(checkboxes) are selected
function numcheckboxselect() {
    var count = 0;
    flag = false;
    var ret = document.querySelectorAll('input[type=checkbox]');
    for (i = 0; i < ret.length; i++) {
        if (ret[i].checked) {
            count += 1;
        }
    }
    if (count >= 2) {
        flag = true;
    }
    return (flag);
}
//Checks if there is a selected breakfast option
function checkedbreakfast() {
    var img = document.getElementsByName('bropt');
    var flag = false;
    for (var i = 0; i < img.length; i++)
        if (img[i].checked) flag = true;
    return flag;
}
//Dynamically Calculates costs for comforts
function calcComforts() {
    var price = 0;

    var ret = document.querySelectorAll('input[type=checkbox]');
    if (ret[0].checked) {
        price += 1;
    }
    if (ret[1].checked) {
        price += 2;
    }
    if (ret[2].checked) {
        price += 2;
    }
    if (ret[3].checked) {
        price += 5;
    }
    if (ret[4].checked) {
        price += 3;
    }
    if (ret[5].checked) {
        price += 2;
    }
    if (ret[6].checked) {
        price += 4;
    }
    if (ret[7].checked) {
        price += 7;
    }
    document.getElementById("comfortscost").value = price;
    return price;
}
//Breakfast Costs
function calcBreakfast() {
    var comforts = calcComforts();
    var breakfastcost;
    var nobreakfast = document.getElementById("nobreakfast");
    if ((comforts >= 15) || (nobreakfast.checked)) {
        breakfastcost = 0;
    } else
        breakfastcost = 10;
    return breakfastcost;
}
//Total Costs
function calcTotal() {
    var comforts = calcComforts();
    var breakfast = calcBreakfast();
    var days = calculateDays();
    var rprice = roomprice();
    var total = days * (comforts + breakfast + rprice);
    document.getElementById("totalcost").value = total;
    return total;
}
//Calculates roomprice
function roomprice() {
    var ddl = document.getElementById("roomtype");
    var selectedValue = ddl.options[ddl.selectedIndex].value;
    var roomprice;
    if ((selectedValue == "singleroom")) {
        if (check.i == 0) roomprice = 200;
        if (check.i == 1) roomprice = 150;
        if (check.i == 2) roomprice = 300;
        if (check.i == 3) roomprice = 250;
    } else {
        if (check.i == 0) roomprice = 350;
        if (check.i == 1) roomprice = 250;
        if (check.i == 2) roomprice = 450;
        if (check.i == 3) roomprice = 300;
    }
    return roomprice;
}
//Select random checkboxes
function randomize() {
    var ret = document.querySelectorAll('input[type=checkbox]');
    var rand;
    for (var i = 0; i < 7; i++) {
        ret[i].checked = false;
    }
    for (i = 0; i < 6; i++) {
        rand = Math.floor((Math.random() * 8));
        ret[rand].checked = true;
    }
    calcComforts();
    enablecosts();
}
//Clears form 
function resetForm(form) {
    // clearing inputs
    var inputs = form.getElementsByTagName('input');
    for (var i = 0; i < inputs.length; i++) {
        switch (inputs[i].type) {
            case 'text':
                inputs[i].value = '';
            case 'date':
                inputs[i].value = '';

            case 'radio':
            case 'checkbox':
                inputs[i].checked = false;
        }
    }
    // clearing selects
    var selects = form.getElementsByTagName('select');
    for (var i = 0; i < selects.length; i++)
        selects[i].selectedIndex = 0;
}

function securitygen() {
    var security = Math.floor((Math.random() * 9000) + 1000);
    document.getElementById("security").value = security;
}

function Same() {
    flag = false;
    var sec = document.getElementById("security").value
    var ans = document.getElementById("secure-answer").value
    if (sec == ans) {
        alert("Security code matches system's number!");
        enableconfirm();
        flag = true;
    } else {
        window.alert("Wrong security pass please try again!")
        document.getElementById("secure-answer").value = "";
    }
    return flag;
}

function enablecheck() {
    document.getElementById("checksecurity").disabled = false;
}

function generatedisc(cell) {
    var discount = Math.floor((Math.random() * 6) + 5);
    cell.innerHTML = discount;
    var cells = document.getElementsByTagName("td");
    var costs = calcTotal();
    var finalcost = costs - discount;
    document.getElementById("final").value = finalcost;
    for (var i = 0; i < cells.length; i++) {
        cells[i].onclick = null;
    }
}

function enableconfirm() {
    document.getElementById("btn-conf").disabled = false;
}

function successPrompt() {
    alert("Congratulations! Your reservation was made successfully!You will now be redirected to Welcome Page");
}